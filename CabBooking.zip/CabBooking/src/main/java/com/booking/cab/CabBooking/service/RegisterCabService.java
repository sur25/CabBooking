package com.booking.cab.CabBooking.service;

import com.booking.cab.CabBooking.Data.CityDetails;
import com.booking.cab.CabBooking.Data.RegisteredCabDetails;

public interface RegisterCabService {
    String registerCab(RegisteredCabDetails cabDetails);
}
