package com.booking.cab.CabBooking.service.impl;

import com.booking.cab.CabBooking.Data.CityDetails;
import com.booking.cab.CabBooking.repository.CityRepository;
import com.booking.cab.CabBooking.service.RegisterCityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegisterCityServiceImpl implements RegisterCityService {

    @Autowired
    private CityRepository cityRepository;

    @Override
    public String registerCity(CityDetails cityDetails) {
       if(getCityDetailsAlreadyExist(cityDetails)){
           return ":: Can't register this city as service is already there";
        }
        cityRepository.save(cityDetails);
        return "Success";
    }

    public boolean getCityDetailsAlreadyExist(CityDetails cityDetails) {
        return cityRepository.findByName(cityDetails.getName()) != null;
    }

}
