package com.booking.cab.CabBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
