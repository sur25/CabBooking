package com.booking.cab.CabBooking.service;

import com.booking.cab.CabBooking.Data.CityDetails;

public interface RegisterCityService {

    String registerCity(CityDetails cityDetails);
}
