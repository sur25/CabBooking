(function(){
  console.log("Hello FreeMarker Form!");
})();