package com.booking.cab.CabBooking.service.impl;

import com.booking.cab.CabBooking.Data.BookCabDetails;
import com.booking.cab.CabBooking.Data.BookingCabRespone;
import com.booking.cab.CabBooking.Data.RegisteredCabDetails;
import com.booking.cab.CabBooking.repository.CabRepository;
import com.booking.cab.CabBooking.repository.CityRepository;
import com.booking.cab.CabBooking.service.BookCabService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class BookCabServiceImpl implements BookCabService {

    @Autowired
    CityRepository cityRepository;

    @Autowired
    CabRepository cabRepository;

    Date date = new Date();

    @Override
    public BookingCabRespone bookCab(BookCabDetails bookCabDetails) {
        if(serviceInCityAvailable(bookCabDetails.getCurrentCity())) {
            RegisteredCabDetails foundDriver = findCabDetails(bookCabDetails);
            if(foundDriver != null) {
                BookingCabRespone bookingCabRespone = new BookingCabRespone();
                //TODO - Change booking id logic later
                bookingCabRespone.setBookingId(UUID.randomUUID().toString());
                bookingCabRespone.setDriverName(foundDriver.getDriverName());
                bookingCabRespone.setVehicleNumber(foundDriver.getVehicleNumber());
                return  bookingCabRespone;
            }

        }
        return null;
    }

    private boolean serviceInCityAvailable(String currentCity) {
        return cityRepository.findByName(currentCity) != null ? true : false;
    }

    private RegisteredCabDetails findCabDetails(BookCabDetails bookCabDetails) {

        try {
            List<RegisteredCabDetails> cabDetailsList = cabRepository.findByCabState("IDLE");
            List<RegisteredCabDetails> cabDetailsListFilteredWithCity = cabDetailsList.stream().filter(cabDetails -> cabDetails.getCurrentCity().equals(bookCabDetails.getCurrentCity())).collect(Collectors.toList());
            RegisteredCabDetails foundDriver = cabDetailsListFilteredWithCity.stream().collect(Collectors.maxBy(Comparator.comparingLong(cabDetails -> date.getTime() - cabDetails.getModified_on().getTime()))).get();
            cabRepository.delete(foundDriver);
            foundDriver.setCabState("ON_TRIP");
            cabRepository.save(foundDriver);
            return foundDriver;
        } catch (Exception ex) {
            // Log exception
        }
        finally {
            // clear some session if any
        }
        return null;
    }
}
