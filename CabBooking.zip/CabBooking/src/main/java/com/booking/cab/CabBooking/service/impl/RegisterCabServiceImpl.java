package com.booking.cab.CabBooking.service.impl;

import com.booking.cab.CabBooking.Data.RegisteredCabDetails;
import com.booking.cab.CabBooking.repository.CabRepository;
import com.booking.cab.CabBooking.service.RegisterCabService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegisterCabServiceImpl implements RegisterCabService {

    @Autowired
    private CabRepository cabRepository;

    public boolean getCityDetailsAlreadyExist(RegisteredCabDetails cabDetails) {
        return cabRepository.findByVehicleNumber(cabDetails.getVehicleNumber()) != null;
    }

    @Override
    public String registerCab(RegisteredCabDetails cabDetails) {
        if(getCityDetailsAlreadyExist(cabDetails)){
            return ":: Can't register this cab as this cab is already registered with us";
        }
        cabRepository.save(cabDetails);
        return "Success";
    }
}
