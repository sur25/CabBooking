package com.booking.cab.CabBooking.Data;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Data
@Getter
@Setter
@Entity
@Table(name = "registeredCabDetails")
public class RegisteredCabDetails {

    private String driverName;

    @Id
    private String vehicleNumber;

    private String currentCity;

    private String cabState = "IDLE";
    private Date registered_on;
    private Date modified_on;

}
