package com.booking.cab.CabBooking.Data;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class BookingCabRespone {

    public String bookingId;
    public String driverName;
    public String vehicleNumber;


}


