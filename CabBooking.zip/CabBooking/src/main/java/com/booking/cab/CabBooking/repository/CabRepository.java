package com.booking.cab.CabBooking.repository;

import com.booking.cab.CabBooking.Data.RegisteredCabDetails;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CabRepository extends CrudRepository<RegisteredCabDetails, Long> {

    RegisteredCabDetails findByVehicleNumber(String vehicleNumber);

    List<RegisteredCabDetails> findByCabState(String cabState);


}
