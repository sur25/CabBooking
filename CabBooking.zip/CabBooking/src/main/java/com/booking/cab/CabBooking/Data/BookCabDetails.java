package com.booking.cab.CabBooking.Data;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Getter
@Setter
public class BookCabDetails {

    private String customerName;
    private String currentCity;
    private String destinationCity;

}
