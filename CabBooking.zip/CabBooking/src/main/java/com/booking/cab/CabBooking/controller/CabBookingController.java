package com.booking.cab.CabBooking.controller;


import com.booking.cab.CabBooking.Data.BookCabDetails;
import com.booking.cab.CabBooking.Data.BookingCabRespone;
import com.booking.cab.CabBooking.Data.CityDetails;
import com.booking.cab.CabBooking.Data.RegisteredCabDetails;
import com.booking.cab.CabBooking.service.BookCabService;
import com.booking.cab.CabBooking.service.RegisterCabService;
import com.booking.cab.CabBooking.service.RegisterCityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;
import java.util.Map;

@Controller
public class CabBookingController {

    @Autowired
    private BookCabService bookCabService;

    @Autowired
    private RegisterCityService registerCityService;

    @Autowired
    private RegisterCabService registerCabService;


    @PostMapping("/bookCab")
    public String bookCab( BookCabDetails bookCabDetails, Model model) {

        BookingCabRespone bookingCabRespone = bookCabService.bookCab(bookCabDetails);
        model.addAttribute("bookCabDetails", bookingCabRespone);
        return "bookCab";

    }

    @GetMapping("/bookCab")
    public String formBookingCab() {
        return "bookCab";
    }

    @PostMapping("/registerCity")
    public String registerCity(CityDetails cityDetails, Model model) {

        String status = registerCityService.registerCity(cityDetails);
        model.addAttribute("city", cityDetails);
        model.addAttribute("status",status);
        return "registerCity";

    }

    @GetMapping("/registerCity")
    public String formGetForCity() {
        return "registerCity";
    }


    @PostMapping("/registerCab")
    public String registerCab(RegisteredCabDetails cabDetails, Model model) {

        String status = registerCabService.registerCab(cabDetails);
        model.addAttribute("cab", cabDetails);
        model.addAttribute("status",status);
        return "registerCab";

    }

    @GetMapping("/registerCab")
    public String formGetForCab() {
        return "registerCab";
    }


}
