package com.booking.cab.CabBooking.repository;

import com.booking.cab.CabBooking.Data.CityDetails;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CityRepository extends CrudRepository<CityDetails, Long> {

    CityDetails findByName(String name);

}
