package com.booking.cab.CabBooking.service;

import com.booking.cab.CabBooking.Data.BookCabDetails;
import com.booking.cab.CabBooking.Data.BookingCabRespone;

public interface BookCabService {

    BookingCabRespone bookCab(BookCabDetails bookCabDetails);
}
